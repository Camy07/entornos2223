import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class EstadisticaTest {

    @Test
    void testContarPares() {
        Estadistica estadistica = new Estadistica();
        assertEquals(1, estadistica.contarPares(3, 4, 5));
    }

    @Test
    void testContarPrimos() {
        Estadistica estadistica = new Estadistica();
        int primos = estadistica.contarPrimos(3, 4, 5);
        assertEquals(2, primos);
    }

    //Indico que es un test parametrizado
    @ParameterizedTest    
    //Le paso varios valores para que haga el test
    //en formato csv (valores separados por comas)
    //cada linea es lo mismo que pasar un test con esos valores
    @CsvSource({
        "5,3,4,5",
        "9,1,3,9",
        "8,1,8,3"
    })
    @DisplayName("test de mayor")
    //Le indico que son los valores que voy a recibir 
    //en este caso, el primer parametro es lo que espero 
    //recibir y los otros tres son los parametros que
    //recibe el metodo
    void testVerMayor(int esperado, int a ,int b, int c) {
        Estadistica estadistica = new Estadistica();
        assertEquals(esperado, estadistica.verMayor(a, b, c));        

    }

    @Test
    void testVerMedia() {
        Estadistica estadistica = new Estadistica();
        assertEquals(4,0 ,  estadistica.verMedia(1,1,1));
    }

    @Test
    void testVerMenor() {
        Estadistica estadistica = new Estadistica();
        assertEquals(3, estadistica.verMenor(3, 4, 5));

    }
}
