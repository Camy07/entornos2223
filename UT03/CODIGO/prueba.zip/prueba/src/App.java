public class App {
    public static void main(String[] args) throws Exception {
        System.out.println("Hello, World!");

        Estadistica estadistica = new Estadistica();

        System.out.println(estadistica.verMedia(3,3,3));
    }
}
