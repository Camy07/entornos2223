public class Estadistica {

    public int verMayor(int a, int b, int c) {
        int mayor = 0;
        if (a >= b && a >= c)
            mayor = a;
        if (b >= c && b >= a)
            mayor = b;
        if (c >= b && c >= a)
            mayor = c;
        return mayor;
    }

    public int verMenor(int a, int b, int c) {
        int mayor = 0;
        if (a <= b && a <= c)
            mayor = a;
        if (b <= c && b <= a)
            mayor = b;
        if (c <= b && c <= a)
            mayor = c;
        return mayor;
    }

    public double verMedia(int a, int b, int c) {
        double suma = a + b + c;
        return (double)(suma / 3.0);
    }

    public int contarPares(int a, int b, int c) {
        int pares = 0;
        if (a % 2 == 0)
            pares++;
        if (b % 2 == 0)
            pares++;
        if (c % 2 == 0)
            pares++;
        return pares;
    }

    public int contarPrimos(int a, int b, int c) {
        int primos = 0;
        if (esPrimo(a))
            primos++;
        if (esPrimo(b))
            primos++;
        if (esPrimo(c))
            primos++;
        return primos;
    }

    private boolean esPrimo(int numero) {
        // El 0, 1 y 4 no son primos
        if (numero == 0 || numero == 1 || numero == 4) {
            return false;
        }
        for (int x = 2; x < numero / 2; x++) {
            // Si es divisible por cualquiera de estos números, no
            // es primo
            if (numero % x == 0)
                return false;
        }
        // Si no se pudo dividir por ninguno de los de arriba, sí es primo
        return true;
    }

}