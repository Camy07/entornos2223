# EXAMEN ENTORNOS UT04 (7-03-2023)
Dado el código adjunto se pide refactorizar y documentar el proyecto, llevando a cabo las acciones necesarias.

#### REFACTORIZACIÓN
Para ello, se debe adjuntar al documento actual las acciones de refactorización llevadas a cabo por cada archivo.

#### DOCUMENTACIÓN 
Además se adjuntará la documentación creada en una carpeta llamada `docs`.

#### TODO ELLO SE DEBE COMPRIMIR Y SUBIR EL ARCHIVO COMPRIMIDO A LA TAREA.


## ACCIONES DE REFACTORIZACIÓN
(INDICAR LAS ACCIONES POR CADA ARCHIVO EN GUIONES)
### Barco.java
- Renombrado de atributo tieneMotor a llevaMotor

### Vehiculo.java
-
### Terrestre.java
-
### Submarino.java
-
### Moto.java
-
### Helicoptero.java
-
### Coche.java
-
### Avion.java
-
### App.java
-
### Aereo.java
-
### Acuatico.java
-

