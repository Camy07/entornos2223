public class Barco extends Acuatico {

    private boolean tieneMotor;
    
    // Constructor
    public Barco(String matricula, String modelo, double eslora, boolean tieneMotor)
    {
        super(matricula, modelo, eslora);
        this.tieneMotor = tieneMotor;
    }
    
    // Sobrescritura del método imprimir
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        if(this.tieneMotor)
        {
            System.out.println("Barco con motor");
        }
        else
        {
            System.out.println("Barco sin motor");
        }        
    }    
    
}
