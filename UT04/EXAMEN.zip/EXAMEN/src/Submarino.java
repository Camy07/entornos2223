public class Submarino extends Acuatico {
    
    // Atributos
    private double profundidadMax;
    
    // Constructor
    public Submarino(String matricula, String modelo, double eslora, double profundidadMax) 
    {
        super(matricula, modelo, eslora);       
        this.profundidadMax = profundidadMax;       
    }

    
    // Sobrescritura del método imprimir
    @Override
    public void imprimir() 
    {
        super.imprimir();
        
        System.out.println("Submarino tiene una profundidad máxima de: " + this.profundidadMax);
    }
    
}
