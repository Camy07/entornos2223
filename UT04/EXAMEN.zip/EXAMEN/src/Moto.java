public class Moto extends Terrestre{
    
String color;
Integer cilindrada;
//Caracter que guarda el tipo de carnet necesario para conducirla
char caracter;
    
    // Constructor
    public Moto (String matricula, String modelo, int numeroRuedas, String color , Integer cilindrada)
    {
        super(matricula, modelo, numeroRuedas);
        this.color = color;
        this.cilindrada = cilindrada;
        switch (cilindrada) {
            case 50:
                this.caracter = 'A';
                break;
            case 125:
                this.caracter = 'B';
                break;
            case 250:
            case 500:
                this.caracter = 'C';
                break;
            case 1000:
            case 1500:
                this.caracter = 'D';
                break;
            default:
                this.caracter='N';
                break;
        }
    }
    
    // Getters y setters
    public String getColor()
    {
        return this.color;
    }
    
    public void setTieneAA(String color)
    {
        this.color = color;
    }
    
    // Sobrescritura del método imprimir
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        System.out.println("Moto de color " + this.getColor());               
    }
    
}
