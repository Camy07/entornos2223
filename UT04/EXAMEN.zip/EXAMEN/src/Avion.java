public class Avion extends Aereo{
    
    // Atributo que guarda el tiempo maximo de vuelo
    private double max;

    public Avion(String matricula, String modelo, int numeroAsientos, double max)
    {
        super(matricula, modelo, numeroAsientos);
        this.max = max;
    }

    @Override
    public void imprimir()
    {
        super.imprimir();
        
        System.out.println("Avión tiene un tiempo máximo de vuelo de: " +
                this.max);
        
    }
}
