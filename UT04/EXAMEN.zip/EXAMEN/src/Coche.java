import java.util.Scanner;

public class Coche extends Terrestre {
    
boolean tieneAA;
//Atributo que guarda el precio del seguro del coche
double valor;

    // Constructor
    public Coche (String matricula, String modelo, int numeroRuedas, boolean tieneAA)
    {
        super(matricula, modelo, numeroRuedas);
        this.tieneAA = tieneAA;
        System.out.println("Cuantos años tienes el carnet?");
        Scanner sc = new Scanner(System.in);
        int num=sc.nextInt();
        sc.nextLine();
        if (num>10) {
            System.out.println("Has tenido algún accidente?(S/N)");
            String accidente = sc.nextLine();
            if (accidente.equalsIgnoreCase("S")) {
                valor=400;
            }
            else {
                valor=300;
            }
        }
        else {
            valor=600;
        }
    }
    
    // Sobrescritura del método imprimir
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        if(this.tieneAA)
        {
            System.out.println("Coche con aire accondicionado");
        }
        else
        {
            System.out.println("Coche sin aire acondicionado");
        }       
    }    
}
