public class Helicoptero extends Aereo{
    
    // Atributo que guarda el numero de helices
    private int h;
    
    // Constructor
    public Helicoptero(String matricula, String modelo, int numeroAsientos, int numeroHelices)
    {
        super(matricula, modelo, numeroAsientos);
        this.h = numeroHelices;
    }

    
    // Sobrescritura del método imprimir
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        System.out.println("Helicóptero tiene " + h + " hélices");
        
    }
    
}
