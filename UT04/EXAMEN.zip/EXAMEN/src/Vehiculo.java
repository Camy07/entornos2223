public class Vehiculo {

    protected final String matricula;
String modelo;


    public Vehiculo(String matricula, String modelo)
    {
        this.matricula = matricula;
        this.modelo = modelo;
    }

    public String getMatricula() 
    {
        return matricula;
    }

    public void imprimir() {
        System.out.println("Matrícula: " + matricula);
    }
    
}
