public class Aereo extends Vehiculo {
    
int numeroAsientos;

    public Aereo(String matricula, String modelo, int numeroAsientos)
    {
        super(matricula, modelo);
        if(matricula.length()==4)
        {
            this.numeroAsientos = numeroAsientos;
        }
        else
        {
            this.numeroAsientos = 0;
            System.out.println("ERROR: Matrícula no válida");
        }
        
    }

    @Override
    public void imprimir()
    {
        System.out.println("Vehículo aéreo --> Matrícula: " +
                this.getMatricula() + " - Modelo: " + this.modelo +
                " - Nº asientos: " + this.getNumeroAsientos());
    }
    
}
