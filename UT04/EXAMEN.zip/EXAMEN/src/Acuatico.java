public class Acuatico extends Vehiculo {
double eslora;

    public Acuatico(String matricula, String modelo, double eslora)
    {
        super(matricula, modelo);
        
        if(matricula.length()<9 && matricula.length()>3)
        {
            this.eslora = eslora;
        }
        else
        {
            this.eslora = 0;
            System.out.println("ERROR: Matrícula no válida");
        }        
    }
    
    // Getters
    public double getEslora()
    {
        return eslora;
    }

    @Override
    public void imprimir()
    {
        System.out.println("Vehículo acuático --> Matrícula: " +
                this.matricula + " - Modelo: " + this.modelo +
                " - Eslora: " + this.getEslora());
    }
    
}
