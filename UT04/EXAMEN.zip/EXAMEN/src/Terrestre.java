public class Terrestre extends Vehiculo {
    
int numeroRuedas;
    
    // Constructor
    public Terrestre(String matricula, String modelo, int numeroRuedas)
    {
        super(matricula, modelo);
        if(matricula.length()==6 && matricula.substring(0,1).equals('A'))
        {
           this.numeroRuedas = numeroRuedas;  
        }
        else
        {
            this.numeroRuedas = 0;
            System.out.println("ERROR: Matrícula no válida");
        }     
    }


    @Override
    public void imprimir()
    {
        System.out.println("Vehículo terrestre --> Matrícula: " +
                matricula + " - Modelo: " + modelo + " - Nº ruedas: " +
                this.getNumeroRuedas());
    }
    
}
